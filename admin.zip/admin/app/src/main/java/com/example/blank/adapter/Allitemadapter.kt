package com.example.blank.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.blank.databinding.ActivityMainBinding
import com.example.blank.databinding.ItemBinding

class Allitemadapter(private val MenuItemNAme:ArrayList<String>,private val MenuItemPrize:ArrayList<String>,private val MenuItemImage:ArrayList<Int>): RecyclerView.Adapter<Allitemadapter.AddItemViewHolder>() {
    private val itemQuantities =IntArray(MenuItemNAme.size){1}
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AddItemViewHolder {
       val binding=ItemBinding.inflate(LayoutInflater.from(parent.context),parent,false)
        return AddItemViewHolder(binding)
    }



    override fun onBindViewHolder(holder: AddItemViewHolder, position: Int) {
holder.bind(position)
    }

    override fun getItemCount(): Int =MenuItemNAme.size
    inner  class AddItemViewHolder(private val binding: ItemBinding):RecyclerView.ViewHolder(binding.root) {
        fun bind(position: Int) {
        binding.apply {
            val quantity =itemQuantities[position]
            foodname.text=MenuItemNAme[position]
            fooditemprize.text=MenuItemPrize[position]
            cartimage.setImageResource(MenuItemImage[position])
            foodItemQuantity.text=quantity.toString()
            minusbutton.setOnClickListener {
                decreaseQuantity(position)
            }
            plusbutton.setOnClickListener {
                increaseQuantity(position)
            }
            delete.setOnClickListener {
                deleteQuantity(position)
            }
        }
        }

        private fun decreaseQuantity(position: Int) {
            if (itemQuantities[position] > 1) {
                itemQuantities[position]--
                binding.foodItemQuantity.text = itemQuantities[position].toString()
            }
        }
        private fun increaseQuantity(position: Int) {
            if (itemQuantities[position] < 10) {
                itemQuantities[position]++
                binding.foodItemQuantity.text = itemQuantities[position].toString()
            }
        }
        private fun deleteQuantity(position: Int){
            MenuItemNAme.removeAt(position)
            MenuItemImage.removeAt(position)
            MenuItemImage.removeAt(position)
            notifyItemRemoved(position)
            notifyItemRangeChanged(position,MenuItemNAme.size)

        }

    }

}