package com.example.blank

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.blank.adapter.Allitemadapter
import com.example.blank.databinding.ActivityAdditemBinding
import com.example.blank.databinding.ActivityAllitemactivityBinding

class allitemactivity : AppCompatActivity() {
    private val binding: ActivityAllitemactivityBinding by lazy {
        ActivityAllitemactivityBinding.inflate(layoutInflater)
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(binding.root)
        val menufoodname = listOf("buger","momo")
        val menufoodprize = listOf("5","6")
        val menuimg = listOf(R.drawable.img_3,R.drawable.img)
        val adapter = Allitemadapter(ArrayList(menufoodname), ArrayList(menufoodprize),
            ArrayList(menuimg)
        )
        binding.menurecyclerview.layoutManager=LinearLayoutManager(this)
        binding.menurecyclerview.adapter=adapter

        binding.backbutton.setOnClickListener{
            val intent = Intent(this,MainActivity::class.java)
            startActivity(intent)
        }
        }
    }
